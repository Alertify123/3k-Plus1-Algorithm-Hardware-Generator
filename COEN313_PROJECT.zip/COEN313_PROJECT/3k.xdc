# Vivado does not support old UCF syntax
# must use XDC syntax


set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets clk]
set_property -dict { PACKAGE_PIN J15 IOSTANDARD LVCMOS33 }   [ get_ports { reset }  ] ;

set_property -dict { PACKAGE_PIN N17    IOSTANDARD LVCMOS33 } [get_ports { clk }];

set_property -dict { PACKAGE_PIN U17 IOSTANDARD LVCMOS33 }   [ get_ports { number_out[6] }  ] ;
set_property -dict { PACKAGE_PIN V17 IOSTANDARD LVCMOS33 }   [ get_ports { number_out[5] }  ] ;
set_property -dict { PACKAGE_PIN R18 IOSTANDARD LVCMOS33 }   [ get_ports { number_out[4] }  ] ;
set_property -dict { PACKAGE_PIN N14 IOSTANDARD LVCMOS33 }   [ get_ports { number_out[3] }  ] ;
set_property -dict { PACKAGE_PIN J13 IOSTANDARD LVCMOS33 }   [ get_ports { number_out[2] }  ] ;
set_property -dict { PACKAGE_PIN K15 IOSTANDARD LVCMOS33 }   [ get_ports { number_out[1] }  ] ;
set_property -dict { PACKAGE_PIN H17 IOSTANDARD LVCMOS33 }   [ get_ports { number_out[0] }  ] ;


set_property -dict { PACKAGE_PIN V12 IOSTANDARD LVCMOS33 }   [ get_ports { term_out[6] }  ] ;
set_property -dict { PACKAGE_PIN V14 IOSTANDARD LVCMOS33 }   [ get_ports { term_out[5] }  ] ;
set_property -dict { PACKAGE_PIN V15 IOSTANDARD LVCMOS33 }   [ get_ports { term_out[4] }  ] ;
set_property -dict { PACKAGE_PIN T16 IOSTANDARD LVCMOS33 }   [ get_ports { term_out[3] }  ] ;
set_property -dict { PACKAGE_PIN U14 IOSTANDARD LVCMOS33 }   [ get_ports { term_out[2] }  ] ;
set_property -dict { PACKAGE_PIN T15 IOSTANDARD LVCMOS33 }   [ get_ports { term_out[1] }  ] ;
set_property -dict { PACKAGE_PIN V16 IOSTANDARD LVCMOS33 }   [ get_ports { term_out[0] }  ] ;

set_property -dict { PACKAGE_PIN V11 IOSTANDARD LVCMOS33 }   [ get_ports { done_out }  ] ;






